package Brate;
import java.util.Scanner;

public class Cifre {

	public static void main(String[] args) {
		int N, Min = 0, Max = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Unesite broj: ");
		N = sc.nextInt();
		
		while (N != 0) {
			Max = N % 10;
			N /= 10;
		}
		if (Min == Max) {
			System.out.println("Sve cifre su iste.");
			} else {
			System.out.println("Cifre nisu iste.");			
		}

	}

}
