package Brate;
import java.util.Scanner;

public class ApsolutnaVrednost {

	public static void main(String[] args) {
		int N;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Unesite broj: ");
		N = sc.nextInt();
		
		if (N < 0) {
			N = -N;
		}
		System.out.println("Apsolutna vrednost broja je: " + N);

	}

}
