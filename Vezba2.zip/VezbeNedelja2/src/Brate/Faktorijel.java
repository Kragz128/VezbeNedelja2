package Brate;
import java.util.Scanner;

public class Faktorijel {

	public static void main(String[] args) {
		
		int P = 1;
		int n;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Unesite broj: ");
		n = sc.nextInt();
		
		for (int i = 1; i <= n; i++) {
			P *= i;
		}
		System.out.println("Faktorijel broja " + n + " je: " + P);

	}

}
