package Brate;
import java.util.Scanner;

public class VrednostFunkcije {

	public static void main(String[] args) {
		int x;
		float f = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Unesite vrednost x: ");
		x = sc.nextInt();
		
		if (x < 1) {
			f = x * x;
			} else if (x > 1 && x < 5) {
				f = 2 - x;
				} else if (x >= 5) {
					f = (float) (x * x * x -1) / 5;
		}
		System.out.println("Vrednost funkcije f(x) je: " + f);

	}

}
